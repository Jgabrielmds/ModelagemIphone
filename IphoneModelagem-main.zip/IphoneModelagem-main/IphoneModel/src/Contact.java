public class Contact {
    String name;
    String lastname;
    int number;
}
