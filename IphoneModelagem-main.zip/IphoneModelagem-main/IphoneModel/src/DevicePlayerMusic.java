public interface DevicePlayerMusic {
    public void play();
    public void pause();
    public void stop();
    public void suffle();
    public void nextMusic();
    public void backMusic();
}
