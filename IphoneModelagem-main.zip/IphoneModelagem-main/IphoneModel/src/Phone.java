public interface Phone {
    public void call();
    public void receiveCall();
    public void voiceMail();
    public void SMS();
}
