public interface Internet {
    public void connection();
    public void pageBroser();
}
