public class Music {
    String name;
    String autor;
    int year;
    double time;
}
